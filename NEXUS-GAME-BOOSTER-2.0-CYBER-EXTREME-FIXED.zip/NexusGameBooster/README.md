# NEXUS GAME BOOSTER 2.0 — CYBER EXTREME

Native Android application built with Kotlin and Jetpack Compose.

## Included

- Animated cyber dashboard with live RAM, battery, temperature, storage and network readings.
- Five-section navigation: Home, Games, Performance, Device and Tools.
- Installed launcher-app library with app icons, search and launch actions.
- Performance Lab with live memory pressure visualization and safe Android settings shortcuts.
- Draggable floating HUD overlay (requires the user to grant Display over other apps permission).
- Device information: Android build, manufacturer/model, CPU/hardware identifiers, ABI, memory and storage.
- NEXUS-only cache cleanup. It does not claim to clear other apps' memory or data.
- GitHub Actions workflow that builds a debug APK on every push to `main`.

## Build

1. Open this folder in Android Studio (recent stable version).
2. Allow Gradle sync to finish.
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

Or run from a machine with Android SDK and Gradle 8.11.1:

```bash
gradle assembleDebug
```

## Permissions

- `SYSTEM_ALERT_WINDOW`: only used when the user enables the floating HUD.
- `POST_NOTIFICATIONS` and foreground-service permissions: used for the user-started HUD service.
- `ACCESS_NETWORK_STATE`: reads the active connection type.
- Launcher intent visibility is declared with a `<queries>` intent. The app does not request broad `QUERY_ALL_PACKAGES` access.

## Honest platform limits

A normal third-party Android app cannot reliably read another game's private FPS/GPU telemetry, force GPU/CPU clocks, or terminate other apps' processes. NEXUS shows only values exposed by Android and opens system settings for controls that Android owns. RAM figures are system-level estimates; battery temperature is the battery sensor reading, not CPU/GPU temperature.

## Release note

This source project is prepared for Android Studio and CI. A signed release APK requires your own signing key and release configuration. The GitHub Actions workflow produces a debug APK artifact, not a Play Store-ready signed release.
