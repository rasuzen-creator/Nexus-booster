package com.nexus.booster

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay
import java.io.File

private val Bg = Color(0xFF070912)
private val Surface = Color(0xFF101626)
private val Surface2 = Color(0xFF151F32)
private val Cyan = Color(0xFF37E7FF)
private val Purple = Color(0xFF9B65FF)
private val Green = Color(0xFF51F2B2)
private val Muted = Color(0xFF91A0B8)
private val Border = Color(0xFF26334A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(7, 9, 18)
        window.navigationBarColor = android.graphics.Color.rgb(7, 9, 18)
        window.decorView.systemUiVisibility = 0
        setContent { NexusApp() }
    }
}

private enum class Page(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    HOME("Home", Icons.Default.SpaceDashboard), GAMES("Games", Icons.Default.SportsEsports), LAB("Performance", Icons.Default.Bolt), DEVICE("Device", Icons.Default.Memory), TOOLS("Tools", Icons.Default.Tune)
}

@Composable
private fun NexusApp() {
    val context = LocalContext.current
    SideEffect { NexusContextHolder.context = context.applicationContext }
    var page by remember { mutableStateOf(Page.HOME) }
    var snapshot by remember { mutableStateOf(DeviceMonitor.read(context)) }
    var games by remember { mutableStateOf(emptyList<GameApp>()) }
    var query by remember { mutableStateOf("") }
    var hudDialog by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf("") }
    var showAbout by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        games = GameApps.load(context)
        while (true) { snapshot = DeviceMonitor.read(context); delay(1800) }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Surface, onSurface = Color.White)) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            Column(Modifier.fillMaxSize()) {
                TopBar(onAbout = { showAbout = true })
                AnimatedContent(page, modifier = Modifier.weight(1f), label = "page-transition") { target ->
                    when (target) {
                        Page.HOME -> HomeScreen(snapshot, games.size, onNavigate = { page = it }, onHud = { hudDialog = true }, onToast = { toast = it })
                        Page.GAMES -> GamesScreen(games, query, { query = it }, onLaunch = { launchGame(context, it) }, onToast = { toast = it })
                        Page.LAB -> PerformanceScreen(snapshot, onHud = { hudDialog = true }, onToast = { toast = it })
                        Page.DEVICE -> DeviceScreen(snapshot)
                        Page.TOOLS -> ToolsScreen(snapshot, onHud = { hudDialog = true }, onToast = { toast = it })
                    }
                }
                BottomNavigation(page) { page = it }
            }
            if (toast.isNotBlank()) {
                LaunchedEffect(toast) { delay(2300); toast = "" }
                Surface(Modifier.align(Alignment.BottomCenter).padding(bottom = 88.dp).padding(horizontal = 22.dp), color = Color(0xFF1C2B42), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, Cyan.copy(.35f)), shadowElevation = 12.dp) {
                    Text(toast, Modifier.padding(horizontal = 18.dp, vertical = 12.dp), color = Color.White, fontSize = 12.sp)
                }
            }
        }
    }
    if (hudDialog) HudPermissionDialog(onDismiss = { hudDialog = false }, onEnable = {
        hudDialog = false
        if (!Settings.canDrawOverlays(context)) context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
        else ContextCompat.startForegroundService(context, Intent(context, HudService::class.java))
    })
    if (showAbout) AlertDialog(onDismissRequest = { showAbout = false }, containerColor = Surface, title = { Text("NEXUS 2.0  •  CYBER EXTREME", color = Color.White, fontWeight = FontWeight.Black) }, text = { Text("Real-time device insights, game launcher and Android quick controls. Metrics are limited to data Android exposes to regular apps.", color = Muted) }, confirmButton = { TextButton(onClick = { showAbout = false }) { Text("CLOSE", color = Cyan) } })
}

@Composable private fun TopBar(onAbout: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Bg).padding(start = 20.dp, end = 18.dp, top = 15.dp, bottom = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(43.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Cyan, Purple))), contentAlignment = Alignment.Center) { Icon(Icons.Default.Bolt, null, tint = Bg, modifier = Modifier.size(28.dp)) }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text("NEXUS", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Text("GAME BOOSTER  /  CYBER EXTREME", color = Cyan, fontSize = 8.sp, letterSpacing = 1.25.sp, fontWeight = FontWeight.Bold)
        }
        Box(Modifier.size(8.dp).clip(CircleShape).background(Green))
        Spacer(Modifier.width(6.dp))
        Text("LIVE", color = Green, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(10.dp))
        IconButton(onClick = onAbout, modifier = Modifier.size(34.dp)) { Icon(Icons.Default.Info, null, tint = Muted, modifier = Modifier.size(19.dp)) }
    }
}

@Composable private fun HomeScreen(s: DeviceSnapshot, gameCount: Int, onNavigate: (Page) -> Unit, onHud: () -> Unit, onToast: (String) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(start = 17.dp, end = 17.dp, top = 5.dp, bottom = 22.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item {
            Text("COMMAND CENTER", color = Muted, fontSize = 10.sp, letterSpacing = 2.4.sp, fontWeight = FontWeight.Bold)
            Text("Ready to dominate?", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Text("Your device. Your arena. Your control.", color = Muted, fontSize = 11.sp)
        }
        item { HeroPanel(s, onBoost = { onNavigate(Page.LAB) }) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("RAM USAGE", "${s.ramPercent}%", "${DeviceMonitor.fmt(s.usedRam)} / ${DeviceMonitor.fmt(s.totalRam)}", Icons.Default.Memory, Modifier.weight(1f))
                StatCard("BATTERY", "${s.battery}%", if (s.charging) "Charging" else "${s.batteryTemp}°C sensor", Icons.Default.BatteryChargingFull, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("APP MEMORY", DeviceMonitor.fmt(s.appRam), "NEXUS process PSS", Icons.Default.Apps, Modifier.weight(1f))
                StatCard("STORAGE FREE", DeviceMonitor.fmt(s.storageFree), "${DeviceMonitor.fmt(s.storageTotal)} total", Icons.Default.Storage, Modifier.weight(1f))
            }
        }
        item { SectionTitle("QUICK DEPLOY", "Fast access to your gaming tools") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                QuickButton("GAME LIBRARY", Icons.Default.SportsEsports, Modifier.weight(1f)) { onNavigate(Page.GAMES) }
                QuickButton("LIVE HUD", Icons.Default.PictureInPictureAlt, Modifier.weight(1f)) { onHud() }
                QuickButton("DEVICE INFO", Icons.Default.PhonelinkSetup, Modifier.weight(1f)) { onNavigate(Page.DEVICE) }
            }
        }
        item { SectionTitle("SYSTEM STATUS", "Live readings · refreshes automatically") }
        item { StatusLine("Network", s.network, Icons.Default.Wifi, Green) }
        item { StatusLine("Processor cores", "${s.cpuCores} logical cores", Icons.Default.DeveloperBoard, Cyan) }
        item { StatusLine("Android", "${s.android}  •  SDK ${android.os.Build.VERSION.SDK_INT}", Icons.Default.Android, Purple) }
        item { Text("NEXUS does not fake FPS or claim to overclock hardware. It gives you reliable readings and shortcuts Android allows.", color = Muted, fontSize = 10.sp, lineHeight = 16.sp, modifier = Modifier.padding(top = 2.dp)) }
    }
}

@Composable private fun HeroPanel(s: DeviceSnapshot, onBoost: () -> Unit) {
    val infinite = rememberInfiniteTransition(label = "hero-pulse")
    val glow by infinite.animateFloat(0.25f, 0.65f, infiniteRepeatable(tween(1700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "glow")
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Brush.linearGradient(listOf(Color(0xFF142B43), Color(0xFF21163C), Color(0xFF101827)))).border(1.dp, Cyan.copy(alpha = glow), RoundedCornerShape(26.dp)).padding(18.dp)) {
        Canvas(Modifier.matchParentSize()) {
            for (i in 0..8) drawLine(Cyan.copy(alpha = .045f), Offset(size.width * i / 8f, 0f), Offset(size.width * i / 8f, size.height), 1f)
            for (i in 0..5) drawLine(Purple.copy(alpha = .045f), Offset(0f, size.height * i / 5f), Offset(size.width, size.height * i / 5f), 1f)
        }
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("SYSTEM OVERVIEW", color = Cyan, fontSize = 9.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text(s.device, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("ANDROID ${s.android.uppercase()}  •  ${s.cpuCores} CORES", color = Muted, fontSize = 8.sp, letterSpacing = .8.sp)
                }
                Ring(s.ramPercent, "RAM", "${s.ramPercent}%", 84.dp)
            }
            Spacer(Modifier.height(18.dp))
            Button(onClick = onBoost, modifier = Modifier.fillMaxWidth().height(51.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent), contentPadding = PaddingValues(0.dp)) {
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Cyan, Color(0xFF8D72FF)))), contentAlignment = Alignment.Center) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Bolt, null, tint = Bg); Spacer(Modifier.width(8.dp)); Text("OPEN PERFORMANCE LAB", color = Bg, fontWeight = FontWeight.Black, letterSpacing = 1.sp, fontSize = 12.sp); Spacer(Modifier.width(8.dp)); Icon(Icons.Default.ArrowForward, null, tint = Bg, modifier = Modifier.size(16.dp)) }
                }
            }
        }
    }
}

@Composable private fun Ring(value: Int, label: String, valueText: String, size: androidx.compose.ui.unit.Dp) {
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            drawArc(Color(0xFF31445D), -90f, 360f, false, style = Stroke(7.dp.toPx()))
            drawArc(Brush.sweepGradient(listOf(Cyan, Purple, Cyan)), -90f, value.coerceIn(0, 100) * 3.6f, false, style = Stroke(7.dp.toPx(), cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(valueText, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black); Text(label, color = Muted, fontSize = 8.sp, letterSpacing = 1.sp) }
    }
}

@Composable private fun StatCard(title: String, value: String, sub: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(19.dp)).background(Surface).border(1.dp, Border, RoundedCornerShape(19.dp)).padding(13.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Cyan, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(7.dp)); Text(title, color = Muted, fontSize = 8.sp, letterSpacing = .8.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(10.dp))
        Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(sub, color = Muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable private fun SectionTitle(title: String, subtitle: String) {
    Column { Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp); Text(subtitle, color = Muted, fontSize = 9.sp) }
}

@Composable private fun QuickButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) .96f else 1f, label = "quick-scale")
    Column(modifier.scale(scale).clip(RoundedCornerShape(17.dp)).background(Surface2).border(1.dp, Border, RoundedCornerShape(17.dp)).clickable { pressed = true; onClick(); pressed = false }.padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(Cyan.copy(.12f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Cyan, modifier = Modifier.size(19.dp)) }
        Spacer(Modifier.height(8.dp)); Text(label, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = .4.sp)
    }
}

@Composable private fun StatusLine(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Surface).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(10.dp)); Text(label, color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f)); Text(value, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable private fun GamesScreen(games: List<GameApp>, query: String, onQuery: (String) -> Unit, onLaunch: (GameApp) -> Unit, onToast: (String) -> Unit) {
    val filtered = remember(games, query) { games.filter { it.label.contains(query, true) || it.packageName.contains(query, true) } }
    Column(Modifier.fillMaxSize().padding(horizontal = 17.dp)) {
        Spacer(Modifier.height(5.dp)); Text("GAME CENTER", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black); Text("Installed launchable apps · ${games.size} detected", color = Muted, fontSize = 10.sp)
        Spacer(Modifier.height(13.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Surface).border(1.dp, Border, RoundedCornerShape(14.dp)).padding(horizontal = 13.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Search, null, tint = Muted); Spacer(Modifier.width(8.dp)); BasicTextField(value = query, onValueChange = onQuery, modifier = Modifier.weight(1f), singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 12.sp), decorationBox = { inner -> if (query.isEmpty()) Text("Search apps and games...", color = Muted, fontSize = 12.sp); inner() })
            if (query.isNotEmpty()) IconButton(onClick = { onQuery("") }, modifier = Modifier.size(22.dp)) { Icon(Icons.Default.Close, null, tint = Muted) }
        }
        Spacer(Modifier.height(12.dp))
        if (filtered.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.SportsEsports, null, tint = Muted, modifier = Modifier.size(40.dp)); Text("No matching apps", color = Color.White); Text("Try another search", color = Muted, fontSize = 10.sp) } }
        else LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(bottom = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered, key = { it.packageName }) { game ->
                Column(Modifier.clip(RoundedCornerShape(18.dp)).background(Surface).border(1.dp, Border, RoundedCornerShape(18.dp)).padding(12.dp)) {
                    androidx.compose.foundation.Image(game.icon.toBitmap().asImageBitmap(), null, Modifier.size(48.dp))
                    Spacer(Modifier.height(9.dp)); Text(game.label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(game.packageName, color = Muted, fontSize = 7.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { onLaunch(game); onToast("Launching ${game.label}") }, modifier = Modifier.fillMaxWidth().height(34.dp), contentPadding = PaddingValues(0.dp), shape = RoundedCornerShape(10.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B3A50))) { Icon(Icons.Default.PlayArrow, null, tint = Cyan, modifier = Modifier.size(15.dp)); Spacer(Modifier.width(4.dp)); Text("PLAY", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Black) }
                }
            }
        }
    }
}

@Composable private fun PerformanceScreen(s: DeviceSnapshot, onHud: () -> Unit, onToast: (String) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(17.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item { Text("PERFORMANCE LAB", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black); Text("Live telemetry and safe system actions", color = Muted, fontSize = 10.sp) }
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0xFF172D48), Color(0xFF20183C)))).border(1.dp, Cyan.copy(.3f), RoundedCornerShape(22.dp)).padding(17.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("MEMORY PRESSURE", color = Cyan, fontSize = 9.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold); Text("${s.ramPercent}%", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black); Text("${DeviceMonitor.fmt(s.availableRam)} available", color = Muted, fontSize = 10.sp) }; Ring(s.ramPercent, "RAM", "${s.ramPercent}%", 92.dp) }
                Spacer(Modifier.height(13.dp)); LinearProgressIndicator(progress = { s.ramPercent / 100f }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape), color = if (s.ramPercent > 85) Color(0xFFFF8B62) else Cyan, trackColor = Color(0xFF33425A))
            }
        }
        item { SectionTitle("SAFE ACTIONS", "Actions that work within Android permissions") }
        item { ToolRow("Open battery settings", "Review battery usage and saver mode", Icons.Default.BatterySaver) { openSettings(onToast, "battery") } }
        item { ToolRow("Open network settings", "Manage Wi-Fi and mobile data", Icons.Default.Wifi) { openSettings(onToast, "network") } }
        item { ToolRow("Display settings", "Brightness and refresh-rate options", Icons.Default.DisplaySettings) { openSettings(onToast, "display") } }
        item { ToolRow("App details", "Manage NEXUS permissions and storage", Icons.Default.AppSettingsAlt) { openAppDetails(onToast) } }
        item { ToolRow("Floating gaming HUD", "Show a monitor bubble over games", Icons.Default.PictureInPictureAlt, onHud) }
        item { Text("Android does not let ordinary third-party apps kill other apps, force GPU clocks, or read another game's private FPS/GPU telemetry. NEXUS never fabricates these values.", color = Muted, fontSize = 10.sp, lineHeight = 16.sp) }
    }
}

@Composable private fun ToolRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Surface).border(1.dp, Border, RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(39.dp).clip(RoundedCornerShape(12.dp)).background(Cyan.copy(.1f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Cyan, modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.width(11.dp)); Column(Modifier.weight(1f)) { Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 9.sp) }; Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
}

@Composable private fun DeviceScreen(s: DeviceSnapshot) {
    LazyColumn(contentPadding = PaddingValues(17.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("DEVICE INTELLIGENCE", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black); Text("Hardware profile · live system readings", color = Muted, fontSize = 10.sp) }
        item { DeviceGroup("PROCESSOR", listOf("CPU / hardware" to s.cpuName, "CPU cores" to s.cpuCores.toString(), "Board" to android.os.Build.BOARD, "Hardware ID" to android.os.Build.HARDWARE, "Supported ABI" to android.os.Build.SUPPORTED_ABIS.joinToString())) }
        item { DeviceGroup("ANDROID PLATFORM", listOf("Manufacturer" to android.os.Build.MANUFACTURER, "Model" to android.os.Build.MODEL, "Device" to android.os.Build.DEVICE, "Android version" to s.android, "SDK level" to android.os.Build.VERSION.SDK_INT.toString(), "Build ID" to android.os.Build.ID, "Security patch" to android.os.Build.VERSION.SECURITY_PATCH)) }
        item { DeviceGroup("MEMORY & STORAGE", listOf("Total RAM" to DeviceMonitor.fmt(s.totalRam), "Used RAM" to DeviceMonitor.fmt(s.usedRam), "Available RAM" to DeviceMonitor.fmt(s.availableRam), "NEXUS process PSS" to DeviceMonitor.fmt(s.appRam), "Storage total" to DeviceMonitor.fmt(s.storageTotal), "Storage free" to DeviceMonitor.fmt(s.storageFree))) }
        item { DeviceGroup("POWER & CONNECTIVITY", listOf("Battery level" to "${s.battery}%", "Battery temperature" to "${s.batteryTemp} °C", "Charging" to if (s.charging) "Yes" else "No", "Network" to s.network)) }
    }
}

@Composable private fun DeviceGroup(title: String, rows: List<Pair<String, String>>) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Surface).border(1.dp, Border, RoundedCornerShape(18.dp)).padding(14.dp)) {
        Text(title, color = Cyan, fontSize = 9.sp, letterSpacing = 1.7.sp, fontWeight = FontWeight.Black); Spacer(Modifier.height(7.dp))
        rows.forEachIndexed { index, row ->
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.Top) { Text(row.first, color = Muted, fontSize = 10.sp, modifier = Modifier.weight(1f)); Text(row.second.ifBlank { "Unavailable" }, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1.1f), textAlign = androidx.compose.ui.text.style.TextAlign.End) }
            if (index != rows.lastIndex) HorizontalDivider(color = Border.copy(.65f))
        }
    }
}

@Composable private fun ToolsScreen(s: DeviceSnapshot, onHud: () -> Unit, onToast: (String) -> Unit) {
    val cacheDir = LocalContext.current.cacheDir
    LazyColumn(contentPadding = PaddingValues(17.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("SYSTEM TOOLKIT", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black); Text("Quick controls and maintenance", color = Muted, fontSize = 10.sp) }
        item { ToolRow("Gaming HUD", "Floating live device monitor", Icons.Default.PictureInPictureAlt, onHud) }
        item { ToolRow("Stop floating HUD", "Remove the overlay and background service", Icons.Default.StopCircle) { val ctx = NexusContextHolder.context; if (ctx != null) ctx.stopService(Intent(ctx, HudService::class.java)); onToast("HUD service stopped") } }
        item { ToolRow("Battery & power", "Open Android battery controls", Icons.Default.BatteryChargingFull) { openSettings(onToast, "battery") } }
        item { ToolRow("Internet & connections", "Open Wi-Fi and network controls", Icons.Default.Wifi) { openSettings(onToast, "network") } }
        item { ToolRow("Screen & refresh rate", "Open display configuration", Icons.Default.DisplaySettings) { openSettings(onToast, "display") } }
        item { ToolRow("Do Not Disturb", "Open interruption controls", Icons.Default.DoNotDisturbOn) { openSettings(onToast, "dnd") } }
        item { ToolRow("NEXUS app permissions", "Overlay, notifications and storage", Icons.Default.Security) { openAppDetails(onToast) } }
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Surface).padding(14.dp)) {
                Text("NEXUS APP CACHE", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp)
                Text("${DeviceMonitor.fmt(cacheSize(cacheDir))} temporary app cache", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text("Only NEXUS temporary files can be cleared. Other apps' data is protected by Android.", color = Muted, fontSize = 9.sp, lineHeight = 14.sp)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { val n = clearOwnCache(cacheDir); onToast("Cleared ${DeviceMonitor.fmt(n)} of NEXUS cache") }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1C3D4D)), shape = RoundedCornerShape(11.dp)) { Icon(Icons.Default.DeleteSweep, null, tint = Cyan); Spacer(Modifier.width(7.dp)); Text("CLEAR NEXUS CACHE", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            }
        }
        item { StatusLine("Current RAM usage", "${s.ramPercent}%", Icons.Default.Memory, Cyan) }
    }
}

@Composable private fun BottomNavigation(current: Page, onSelect: (Page) -> Unit) {
    NavigationBar(containerColor = Color(0xFF0B1120), tonalElevation = 0.dp) {
        Page.values().forEach { page -> NavigationBarItem(selected = current == page, onClick = { onSelect(page) }, icon = { Icon(page.icon, null, modifier = Modifier.size(19.dp)) }, label = { Text(page.title, fontSize = 8.sp, maxLines = 1) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Cyan, selectedTextColor = Cyan, indicatorColor = Color(0xFF1B3048), unselectedIconColor = Muted, unselectedTextColor = Muted)) }
    }
}

@Composable private fun HudPermissionDialog(onDismiss: () -> Unit, onEnable: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, containerColor = Surface, title = { Text("ACTIVATE GAMING HUD", color = Color.White, fontWeight = FontWeight.Black) }, text = { Text("Floating HUD needs Android's 'Display over other apps' permission. It shows a compact device status bubble. You can disable it any time from Android settings or the app notification.", color = Muted, fontSize = 12.sp) }, confirmButton = { TextButton(onClick = onEnable) { Text("CONTINUE", color = Cyan, fontWeight = FontWeight.Bold) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("CANCEL", color = Muted) } })
}

private fun launchGame(context: Context, game: GameApp) { try { context.startActivity(game.launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { } }
private fun openSettings(onToast: (String) -> Unit, type: String) {
    val action = when (type) {
        "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
        "network" -> Settings.ACTION_WIRELESS_SETTINGS
        "display" -> Settings.ACTION_DISPLAY_SETTINGS
        else -> Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS
    }
    try { val context = NexusContextHolder.context ?: return; context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { onToast("This setting is unavailable on this device") }
}
private object NexusContextHolder { var context: Context? = null }
private fun openAppDetails(onToast: (String) -> Unit) {
    try { val context = NexusContextHolder.context ?: return; context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { onToast("Could not open app settings") }
}
private fun cacheSize(file: File): Long = try { file.walkTopDown().filter { it.isFile }.sumOf { it.length() } } catch (_: Exception) { 0L }
private fun clearOwnCache(file: File): Long { val before = cacheSize(file); try { file.listFiles()?.forEach { it.deleteRecursively() } } catch (_: Exception) { }; return before }
