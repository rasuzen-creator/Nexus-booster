package com.nexus.booster

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Debug
import android.os.StatFs
import java.io.File
import java.util.Locale

data class DeviceSnapshot(
    val totalRam: Long, val availableRam: Long, val appRam: Long,
    val battery: Int, val batteryTemp: Float, val charging: Boolean,
    val storageTotal: Long, val storageFree: Long, val cpuCores: Int,
    val cpuName: String, val android: String, val device: String,
    val network: String
) {
    val usedRam: Long get() = (totalRam - availableRam).coerceAtLeast(0)
    val ramPercent: Int get() = if (totalRam > 0) (usedRam * 100 / totalRam).toInt() else 0
}

object DeviceMonitor {
    fun read(context: Context): DeviceSnapshot {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val app = Debug.MemoryInfo()
        Debug.getMemoryInfo(app)
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val stat = StatFs(context.filesDir.absolutePath)
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val net = when {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi-Fi"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Mobil tarmoq"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"
            else -> "Ulanmagan / noma'lum"
        }
        val cpu = try {
            File("/proc/cpuinfo").readLines().firstOrNull { it.startsWith("Hardware") || it.startsWith("model name") }
                ?.substringAfter(':')?.trim()?.takeIf { it.isNotBlank() } ?: Build.HARDWARE
        } catch (_: Exception) { Build.HARDWARE }
        return DeviceSnapshot(
            mi.totalMem, mi.availMem, app.totalPss.toLong() * 1024,
            if (scale > 0) level * 100 / scale else 0, temp,
            status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL,
            stat.totalBytes, stat.availableBytes, Runtime.getRuntime().availableProcessors(),
            cpu, Build.VERSION.RELEASE, "${Build.MANUFACTURER} ${Build.MODEL}", net
        )
    }
    fun fmt(bytes: Long): String {
        val gb = bytes / 1024.0 / 1024.0 / 1024.0
        return if (gb >= 1) String.format(Locale.US, "%.2f GB", gb) else String.format(Locale.US, "%.0f MB", bytes / 1024.0 / 1024.0)
    }
}
