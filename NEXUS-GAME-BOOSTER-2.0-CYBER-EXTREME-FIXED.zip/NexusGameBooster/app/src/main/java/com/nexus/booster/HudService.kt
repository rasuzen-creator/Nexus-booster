package com.nexus.booster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView

class HudService : Service() {
    private var window: WindowManager? = null
    private var bubble: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var expanded = false

    override fun onCreate() {
        super.onCreate()
        val channelId = "nexus_hud"
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(channelId, "NEXUS Gaming HUD", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = buildNotification(channelId)
        startForeground(71, notification)
        if (Settings.canDrawOverlays(this)) showBubble()
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(channelId: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId) else Notification.Builder(this)
        return builder.setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("NEXUS Gaming HUD active")
            .setContentText("Floating device monitor is running")
            .setOngoing(true).build()
    }

    @Suppress("DEPRECATION")
    private fun overlayWindowType(): Int = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    private fun showBubble() {
        window = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = TextView(this).apply {
            text = "N"
            textSize = 19f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(45, 224, 255), Color.rgb(125, 77, 255))).apply {
                shape = GradientDrawable.OVAL
                setStroke(2, Color.WHITE)
            }
            setOnTouchListener { _, event ->
                val lp = params ?: return@setOnTouchListener false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { lastX = event.rawX; lastY = event.rawY; startX = lp.x; startY = lp.y; true }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = (startX - (event.rawX - lastX).toInt()).coerceAtLeast(0)
                        lp.y = (startY + (event.rawY - lastY).toInt()).coerceAtLeast(0)
                        try { window?.updateViewLayout(this, lp) } catch (_: Exception) { }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (kotlin.math.abs(event.rawX - lastX) < 8 && kotlin.math.abs(event.rawY - lastY) < 8) toggleReadout()
                        true
                    }
                    else -> true
                }
            }
        }
        bubble = view
        val type = overlayWindowType()
        val lp = WindowManager.LayoutParams(58, 58, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 18; y = 220
        }
        params = lp
        try { window?.addView(view, lp) } catch (_: Exception) { stopSelf() }
    }

    private var lastX = 0f
    private var lastY = 0f
    private var startX = 0
    private var startY = 0

    private fun toggleReadout() {
        val view = bubble ?: return
        expanded = !expanded
        if (expanded) {
            val s = DeviceMonitor.read(this)
            view.text = "RAM ${s.ramPercent}%\nBAT ${s.battery}%\n${s.batteryTemp}°C"
            view.textSize = 10f
            view.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(16, 34, 55), Color.rgb(46, 28, 76))).apply {
                cornerRadius = 22f
                setStroke(2, Color.rgb(55, 231, 255))
            }
            params?.let { it.width = 132; it.height = 94; try { window?.updateViewLayout(view, it) } catch (_: Exception) { } }
        } else {
            view.text = "N"; view.textSize = 19f
            view.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(45, 224, 255), Color.rgb(125, 77, 255))).apply { shape = GradientDrawable.OVAL; setStroke(2, Color.WHITE) }
            params?.let { it.width = 58; it.height = 58; try { window?.updateViewLayout(view, it) } catch (_: Exception) { } }
        }
    }

    override fun onDestroy() {
        try { bubble?.let { window?.removeView(it) } } catch (_: Exception) { }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
