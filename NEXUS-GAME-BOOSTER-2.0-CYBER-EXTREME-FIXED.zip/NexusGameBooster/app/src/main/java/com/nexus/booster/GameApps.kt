package com.nexus.booster

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager

data class GameApp(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable, val launch: Intent)

object GameApps {
    @Suppress("DEPRECATION")
    fun load(context: Context): List<GameApp> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .mapNotNull { ri ->
                val ai = ri.activityInfo?.applicationInfo ?: return@mapNotNull null
                val launch = pm.getLaunchIntentForPackage(ai.packageName) ?: return@mapNotNull null
                GameApp(ri.loadLabel(pm).toString(), ai.packageName, ri.loadIcon(pm), launch)
            }
            .distinctBy { it.packageName }
            .filter { app ->
                try {
                    val info = pm.getApplicationInfo(app.packageName, 0)
                    (info.flags and ApplicationInfo.FLAG_SYSTEM == 0) ||
                        app.label.contains("game", true)
                } catch (_: Exception) { false }
            }
            .sortedBy { it.label.lowercase() }
    }
}
